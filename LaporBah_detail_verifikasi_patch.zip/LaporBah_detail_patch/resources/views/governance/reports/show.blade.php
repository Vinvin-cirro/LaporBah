@extends('layouts.governance')

@section('title', 'Detail & Verifikasi Laporan')
@section('breadcrumb', 'Detail & verifikasi laporan')

@section('content')
@php
    $statusLabels = [
        'pending' => 'Menunggu verifikasi',
        'verified' => 'Terverifikasi',
        'investigating' => 'Sedang ditangani',
        'resolved' => 'Selesai',
        'rejected' => 'Ditolak',
    ];
    $statusColors = [
        'pending' => 'warning',
        'verified' => 'info',
        'investigating' => 'primary',
        'resolved' => 'success',
        'rejected' => 'danger',
    ];
    $priority = $report->activeAssignment?->priority ?? 'normal';
    $priorityLabels = ['normal' => 'Normal', 'high' => 'Tinggi', 'urgent' => 'Mendesak'];
    $latestVerification = $report->updates->whereIn('action', ['verify', 'request_info', 'mark_duplicate', 'reject'])->sortByDesc('created_at')->first();
    $canReview = $report->status === 'pending';
@endphp

<div class="container-fluid px-0">
    <div class="mb-4">
        <h2 class="fw-bold mb-1">Detail & verifikasi laporan</h2>
        <p class="text-secondary mb-3">Manajemen Laporan / {{ $report->tracking_code }}</p>

        <div class="d-flex flex-wrap align-items-center gap-3">
            <a href="{{ route('governance.reports.index') }}" class="btn btn-outline-secondary px-3">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke daftar
            </a>
            <span class="badge rounded-3 bg-{{ $statusColors[$report->status] ?? 'secondary' }}-subtle text-{{ $statusColors[$report->status] ?? 'secondary' }} px-3 py-3">
                {{ $statusLabels[$report->status] ?? ucfirst($report->status) }}
            </span>
            <span class="badge rounded-3 bg-primary-subtle text-primary px-3 py-3">
                Prioritas: {{ $priorityLabels[$priority] ?? ucfirst($priority) }}
            </span>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif

    <div class="row g-3 align-items-stretch">
        {{-- Detail laporan dan laporan serupa --}}
        <div class="col-xl-7">
            <div class="card border shadow-sm rounded-4 mb-3 h-auto">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="fw-bold mb-1">{{ $report->category === 'dark' ? 'Penerangan jalan / area gelap' : 'Laporan begal' }}</h5>
                            <div class="small text-secondary">
                                <span class="fw-semibold text-dark">{{ $report->tracking_code }}</span>
                                <span class="mx-1">•</span>{{ $report->category === 'dark' ? 'PJU / area gelap' : 'Keamanan / begal' }}
                                <span class="mx-1">•</span>Aplikasi warga
                            </div>
                        </div>
                    </div>

                    <p class="text-secondary mb-4" style="white-space: pre-line">{{ $report->description }}</p>

                    <div class="small text-secondary">
                        <div>Kejadian: {{ $report->incident_at?->translatedFormat('j F Y, H.i') ?? 'Tidak dicantumkan' }} WIB</div>
                        <div>Dikirim: {{ $report->created_at?->translatedFormat('j F Y, H.i') }} WIB</div>
                        <div>Lokasi: {{ $report->location_name ?? 'Tidak dicantumkan' }}</div>
                        <div>Koordinat: {{ $report->latitude ?? '-' }}, {{ $report->longitude ?? '-' }}</div>
                        @if($report->latitude !== null && $report->longitude !== null)
                            <a class="d-inline-block mt-2" href="https://www.openstreetmap.org/?mlat={{ $report->latitude }}&mlon={{ $report->longitude }}#map=17/{{ $report->latitude }}/{{ $report->longitude }}" target="_blank" rel="noopener noreferrer">
                                <i class="bi bi-geo-alt me-1"></i>Lihat lokasi di OpenStreetMap
                            </a>
                        @endif
                    </div>

                    <hr class="my-3">
                    <div class="fw-semibold small mb-2">Lampiran foto</div>
                    @forelse($report->images as $image)
                        <a href="{{ Storage::disk('public')->url($image->image_path) }}" target="_blank" rel="noopener noreferrer" class="d-inline-block me-2 mb-2">
                            <img src="{{ Storage::disk('public')->url($image->image_path) }}" alt="Foto bukti laporan" class="img-thumbnail" style="width: 125px; height: 95px; object-fit: cover;">
                        </a>
                    @empty
                        <span class="small text-secondary">Tidak ada foto yang disertakan.</span>
                    @endforelse
                </div>
            </div>

            <div class="card border shadow-sm rounded-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Laporan serupa di sekitar lokasi</h5>
                    @forelse($similarReports as $similar)
                        <div class="d-flex justify-content-between align-items-start gap-3 border-bottom pb-3 mb-3">
                            <div>
                                <div class="fw-semibold">{{ $similar->tracking_code ?? 'Laporan #' . $similar->id }} <span class="text-secondary fw-normal">• {{ ucfirst($similar->category) }}</span></div>
                                <div class="small text-secondary">{{ $similar->location_name ?? 'Lokasi tidak dicantumkan' }}</div>
                                <div class="small text-secondary">{{ $similar->created_at?->translatedFormat('j M Y, H.i') }} WIB · {{ number_format($similar->distance_meters, 0, ',', '.') }} m dari lokasi</div>
                            </div>
                            <a href="{{ route('governance.reports.show', $similar) }}" class="btn btn-sm btn-outline-secondary text-nowrap">Lihat laporan</a>
                        </div>
                    @empty
                        <p class="text-secondary mb-0">Belum ditemukan laporan lain dalam radius 2 km dari lokasi ini.</p>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Panel verifikasi --}}
        <div class="col-xl-5">
            <div class="card border shadow-sm rounded-4 h-100">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Tinjauan verifikasi</h5>
                    <div class="small text-secondary mb-4">
                        <div>Verifikator: <span class="text-dark fw-semibold">{{ auth()->user()->name }}</span></div>
                        <div>Waktu verifikasi: {{ $latestVerification?->created_at?->translatedFormat('j F Y, H.i') ?? 'Belum diverifikasi' }}</div>
                        @if($report->duplicateOf)
                            <div class="mt-1">Duplikat dari: <a href="{{ route('governance.reports.show', $report->duplicateOf) }}">{{ $report->duplicateOf->tracking_code }}</a></div>
                        @endif
                    </div>

                    @if($canReview)
                        <form action="{{ route('governance.reports.update-status', $report) }}" method="POST" id="verificationForm">
                            @csrf
                            @method('PATCH')
                            <div class="mb-2">
                                <label for="note" class="form-label fw-semibold small">Catatan internal <span class="text-danger">*</span></label>
                                <textarea name="note" id="note" class="form-control rounded-3" rows="4" maxlength="1000" placeholder="Tuliskan hasil pemeriksaan laporan..." required>{{ old('note') }}</textarea>
                                <div class="form-text">Catatan ini hanya untuk keperluan internal dan tidak ditampilkan kepada warga.</div>
                            </div>

                            <div class="mb-3 d-none" id="duplicateSelectWrap">
                                <label for="duplicate_of_report_id" class="form-label fw-semibold small">Laporan yang dianggap duplikat</label>
                                <select name="duplicate_of_report_id" id="duplicate_of_report_id" class="form-select">
                                    <option value="">Pilih laporan pembanding</option>
                                    @foreach($similarReports as $similar)
                                        <option value="{{ $similar->id }}">{{ $similar->tracking_code }} — {{ $similar->location_name ?? 'Lokasi tidak dicantumkan' }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <button type="submit" name="action" value="verify" class="btn btn-dark w-100 rounded-3 py-2 mb-2" onclick="return confirm('Verifikasi laporan ini?')">
                                <i class="bi bi-check-circle me-1"></i> Verifikasi laporan
                            </button>
                            <button type="submit" name="action" value="request_info" class="btn btn-outline-secondary w-100 rounded-3 mb-2">
                                Minta informasi tambahan
                            </button>
                            <div class="row g-2">
                                <div class="col-6">
                                    <button type="button" id="duplicateButton" class="btn btn-outline-secondary w-100 rounded-3">Tandai duplikat</button>
                                </div>
                                <div class="col-6">
                                    <button type="submit" name="action" value="reject" class="btn btn-danger-subtle text-danger w-100 rounded-3" onclick="return confirm('Tolak laporan ini?')">Tolak laporan</button>
                                </div>
                            </div>
                            <div class="small text-secondary mt-3">Alasan wajib dicatat untuk penolakan, duplikat, dan permintaan informasi tambahan.</div>
                        </form>
                    @else
                        <div class="alert alert-light border mb-0">
                            <div class="fw-semibold mb-1">Laporan sudah ditinjau</div>
                            <div class="small text-secondary">Tindakan verifikasi berikutnya tidak tersedia karena status laporan saat ini adalah {{ $statusLabels[$report->status] ?? $report->status }}.</div>
                            @if($latestVerification?->note)
                                <hr>
                                <div class="small fw-semibold">Catatan terakhir</div>
                                <div class="small">{{ $latestVerification->note }}</div>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- Audit timeline --}}
    <div class="card border shadow-sm rounded-4 mt-3">
        <div class="card-body p-4">
            <h5 class="fw-bold mb-3">Alur penanganan & jejak audit</h5>
            <div class="d-flex flex-wrap align-items-center gap-2 small fw-semibold mb-3">
                <span>Masuk</span><i class="bi bi-arrow-right"></i>
                <span>Menunggu verifikasi</span><i class="bi bi-arrow-right"></i>
                <span>Diverifikasi</span><i class="bi bi-arrow-right"></i>
                <span>Terverifikasi / Ditolak</span><i class="bi bi-arrow-right"></i>
                <span>Diteruskan</span><i class="bi bi-arrow-right"></i>
                <span>Ditangani</span><i class="bi bi-arrow-right"></i>
                <span>Selesai</span>
            </div>
            <div class="small text-secondary">
                <div class="mb-2"><span class="text-nowrap">{{ $report->created_at?->format('j M, H.i') }}</span> <span class="mx-1">•</span> Laporan diterima sistem</div>
                @forelse($report->updates->sortBy('created_at') as $update)
                    @php
                        $actionLabels = [
                            'verify' => 'Laporan diverifikasi',
                            'request_info' => 'Informasi tambahan diminta',
                            'mark_duplicate' => 'Laporan ditandai sebagai duplikat',
                            'reject' => 'Laporan ditolak',
                            'status_change' => 'Status laporan diperbarui',
                        ];
                    @endphp
                    <div class="mb-2">
                        <span class="text-nowrap">{{ $update->created_at?->format('j M, H.i') }}</span>
                        <span class="mx-1">•</span>
                        {{ $actionLabels[$update->action] ?? 'Status: ' . ucfirst($update->old_status ?? '-') . ' → ' . ucfirst($update->new_status) }}
                        <span class="mx-1">•</span>{{ $update->updater?->name ?? 'Sistem' }}
                        @if($update->note)<div class="ms-3 mt-1">Catatan: {{ $update->note }}</div>@endif
                    </div>
                @empty
                    <div>Belum ada aktivitas verifikasi atau perubahan status.</div>
                @endforelse
            </div>
        </div>
    </div>

    {{-- Penugasan tetap menggunakan wizard yang sudah ada --}}
    <div class="card border shadow-sm rounded-4 mt-3">
        <div class="card-header bg-white py-3 rounded-top-4">
            <h5 class="fw-bold mb-0">Penugasan petugas</h5>
        </div>
        <div class="card-body p-4">
            @if ($report->activeAssignment)
                <div class="alert alert-info">
                    <strong>{{ $report->activeAssignment->officer->name }}</strong><br>
                    <small>{{ $report->activeAssignment->officer->email }}</small><br>
                    <span class="badge bg-success mt-2">Sedang bertugas</span>
                    <div class="small mt-2">{{ $report->activeAssignment->institution_name }} · {{ $report->activeAssignment->team_name }}</div>
                    <div class="small">Prioritas: {{ $priorityLabels[$priority] ?? ucfirst($priority) }} · Batas: {{ $report->activeAssignment->due_at?->format('d/m/Y H:i') ?? '-' }}</div>
                </div>
            @elseif(in_array($report->status, ['resolved', 'rejected']))
                <div class="alert alert-secondary mb-0">Penugasan tidak tersedia karena laporan sudah {{ $report->status === 'resolved' ? 'diselesaikan' : 'ditolak' }}.</div>
            @else
                <div class="alert alert-warning">Belum ada petugas yang ditugaskan.</div>
            @endif

            @if (in_array($report->status, ['verified', 'investigating']))
                <hr>
                @if ($officers->isNotEmpty())
                    @include('governance.reports.assignment-wizard')
                @else
                    <div class="alert alert-warning mb-0">Belum ada akun dengan role Officer.</div>
                @endif
            @elseif(!in_array($report->status, ['resolved', 'rejected']))
                <div class="small text-secondary">Laporan harus diverifikasi sebelum dapat ditugaskan kepada petugas.</div>
            @endif
        </div>
    </div>

    {{-- Riwayat penugasan --}}
    <div class="card border shadow-sm rounded-4 mt-3">
        <div class="card-body p-4">
            <h5 class="fw-bold mb-3">Riwayat penugasan</h5>
            @forelse($report->assignments->sortByDesc('assigned_at') as $assignment)
                <div class="border-bottom pb-3 mb-3">
                    <div class="d-flex justify-content-between flex-wrap gap-2">
                        <strong>{{ $assignment->officer->name }}</strong>
                        <span class="badge bg-{{ $assignment->ended_at ? 'secondary' : 'success' }}">{{ $assignment->ended_at ? 'Selesai' : 'Aktif' }}</span>
                    </div>
                    <small class="text-secondary">{{ $assignment->institution_name }} · {{ $assignment->team_name }}</small><br>
                    <small class="text-secondary">Ditugaskan oleh {{ $assignment->assigner?->name ?? 'Tidak diketahui' }} · {{ $assignment->assigned_at?->format('d/m/Y H:i') ?? '-' }}</small>
                    @if($assignment->ended_at)<div class="small text-secondary">Berakhir: {{ $assignment->ended_at->format('d/m/Y H:i') }}</div>@endif
                    @if($assignment->note)<div class="small mt-1">Instruksi: {{ $assignment->note }}</div>@endif
                </div>
            @empty
                <p class="text-secondary mb-0">Belum ada riwayat penugasan.</p>
            @endforelse
        </div>
    </div>

    <div class="small text-secondary mt-4">
        <i class="bi bi-shield-lock me-1"></i> Privasi: identitas warga disamarkan. Buka data kontak hanya dengan izin dan alasan akses yang tercatat.
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const duplicateButton = document.getElementById('duplicateButton');
    const duplicateWrap = document.getElementById('duplicateSelectWrap');
    const duplicateSelect = document.getElementById('duplicate_of_report_id');
    const form = document.getElementById('verificationForm');

    if (!duplicateButton || !duplicateWrap || !duplicateSelect || !form) return;

    duplicateButton.addEventListener('click', function () {
        duplicateWrap.classList.remove('d-none');
        duplicateSelect.required = true;
        duplicateSelect.focus();

        if (!document.getElementById('confirmDuplicateButton')) {
            const confirmButton = document.createElement('button');
            confirmButton.type = 'submit';
            confirmButton.name = 'action';
            confirmButton.value = 'mark_duplicate';
            confirmButton.id = 'confirmDuplicateButton';
            confirmButton.className = 'btn btn-warning w-100 rounded-3 mt-2';
            confirmButton.textContent = 'Konfirmasi duplikat';
            duplicateWrap.appendChild(confirmButton);
        }
    });

    form.addEventListener('submit', function (event) {
        const isDuplicateAction = event.submitter && event.submitter.value === 'mark_duplicate';
        duplicateSelect.required = Boolean(isDuplicateAction);

        if (isDuplicateAction && !duplicateSelect.value) {
            event.preventDefault();
            duplicateSelect.reportValidity();
        }
    });
});
</script>
@endpush
